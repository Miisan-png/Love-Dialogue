local MODULE_NAME = ...
require(MODULE_NAME .. ".Logic")
require(MODULE_NAME .. ".Tween")
require(MODULE_NAME .. ".Transition")
return require(MODULE_NAME .. ".LoveDialogue")